//
// Created by Omri on 28/12/2021.
//

#include <Message.h>

Message::~Message() {}
