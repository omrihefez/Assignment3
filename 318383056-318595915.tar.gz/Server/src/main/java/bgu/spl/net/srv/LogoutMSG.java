package bgu.spl.net.srv;

public class LogoutMSG extends MSG {


    public LogoutMSG(){
        super((short)3);
    }

}
