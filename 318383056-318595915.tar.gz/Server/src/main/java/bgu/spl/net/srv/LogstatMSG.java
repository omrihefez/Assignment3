package bgu.spl.net.srv;

public class LogstatMSG extends MSG {

    public LogstatMSG(){
        super((short)7);
    }
}
